var mzaCDMX = [
